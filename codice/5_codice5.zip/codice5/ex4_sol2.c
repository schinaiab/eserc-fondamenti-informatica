#include<stdio.h>
// la funzione riceve il riferimento alla variabile, 
 
void calcolaMassimo(int numeri[],int LUN,int *massimo);

int main(){

int LUN = 10;

int numeri[10] = {2,3,4,5,6,412,23,5,1,4};
int massimo;

calcolaMassimo(numeri,LUN,&massimo);//  passo l'indirizzo e la modifica si riperquote
printf("\nmassimo-> %d\n",massimo);
}

void calcolaMassimo(int numeri[],int LUN,int *massimo){

	int i;
	int temp;
	*massimo = numeri[0];
	for(i=0;i<LUN;i++){
		if (*massimo < numeri[i]){
			*massimo = numeri[i];
		}
	}
}
