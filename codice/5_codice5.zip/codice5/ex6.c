#include<stdio.h>
#define MAXLEN 5


/* definiamo il tipo booleano bool */

typedef enum{FALSE=0,TRUE=1} bool;

/* la funzione cercaIntero vuole in input:

	-array di interi in cui cercare
	-lunghezza dell'array di interi
	-il numero da cercare
	-la variabile dove salvare l'indice
*/

bool cercaIntero(int * sequenza, int len, int n, int * indice_n);

/* scrivo anche una procedura utile per stampare il
   risultato della funzione cercaIntero
*/

void printCercaIntero(int * sequenza,int len, int n);


int main(){

	int sequenza[MAXLEN] ={1,2,3,4,5};

	int A=2;
	printCercaIntero(sequenza,MAXLEN,A);
	A=6;
	printCercaIntero(sequenza,MAXLEN,A);
}

bool cercaIntero(int * sequenza, int len, int n, int * indice_n){

	bool trovato = FALSE;
	*indice_n = -1;
	
	for (int i=0; i < len; i++){
		if(sequenza[i]==n){
			*indice_n = i;
			trovato = TRUE;
			break;
		}
	}
	return trovato;
}

void printCercaIntero(int * sequenza, int len, int n){

	int indice;
	if(cercaIntero(sequenza,len,n,&indice)){
		printf("Il valore %d si trova nella sequenza in indice %d\n",
			n, indice);
	}
	else{
		printf("Il valore %d non si trova nella sequenza\n",n);
	}
}


