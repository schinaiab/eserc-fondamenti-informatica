#include<stdio.h>

void calcolaMassimo(int numeri[],int LUN);

int main(){

int LUN = 10;

int numeri[10] = {2,3,4,5,6,412,23,5,1,4};
int massimo;

massimo = calcolaMassimo(numeri,LUN);

}


void calcolaMassimo(int numeri[],int LUN){

	int massimo;
	int i;

	massimo = numeri[0];
	for(i=0;i<LUN;i++){
		if (massimo == numeri[i]){
			massimo = numeri[i];
		}
	}
}
