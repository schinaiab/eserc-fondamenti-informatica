#include<stdio.h>
#include<string.h>

#define NUMLIBRO 3
#define STRLEN 30

typedef struct{
	char nome[STRLEN];
	double costo;
	int giacenza;
	} Libro;

typedef Libro Libreria[NUMLIBRO];
typedef enum {FALSE=0,TRUE=1} bool;

Libreria libreria ={
	{"Informatica\0",10.0,3},
	{"Matematica\0",20.0,5},
	{"Statistica\0",5.0,2}
};

double cassa = 0.0;

void librocomprato(char*nome);


int main(){

char nome[STRLEN] = "Informatica\0";

librocomprato(nome);
librocomprato(nome);
librocomprato(nome);
librocomprato(nome);

printf("In cassa hai %f euro\n",cassa);
return 0;
}



void librocomprato(char*nome){

	/* variabile che indica se
	il libro e' nella libreria 
	inizializzata a FALSE*/

	bool trovato = FALSE;

	for(int i=0; i<NUMLIBRO; i++){
	
	/* compariamo i nomi dei libri */
		if(strcmp(libreria[i].nome,nome)==0){
			trovato = TRUE;
	
			/* guardiamo se il libro e' disponibile*/
			if(libreria[i].giacenza > 0){
				printf("Hai venduto %s con prezzo %f\n",
					nome,libreria[i].costo);
				cassa += libreria[i].costo;
				libreria[i].giacenza--;			
			}
			else{
				printf("Libro non in giacenza\n");
			}
			break;
		}
	}
	if(trovato == FALSE){
		printf("Libro non trovato.\n");
	}


	
}
