#include<stdio.h>
#include<string.h>

#define MAX_L 30 /* Lunghezza massima stringa */

typedef enum{FALSE,TRUE} bool;
typedef char Stringa[MAX_L];

typedef struct{
		int lunghezza;
		int numeroVocali;
		int sommaAscii;
		} AnalisiStringa;

bool carattereVocale(char a); /* restituisce TRUE se il carattere e' una vocale */
AnalisiStringa AnalizzaStringa(Stringa stringa);


int main(){

Stringa stringa;
AnalisiStringa analisiStringa;

printf("Inserisci una stringa (max %d caratteri):\n",MAX_L);
scanf("%s",stringa);

analisiStringa = AnalizzaStringa(stringa);


printf("Lunghezza della stringa: %d \nNumero di vocali: %d\nSomma ASCII %d\n",
	analisiStringa.lunghezza,analisiStringa.numeroVocali,analisiStringa.sommaAscii);
}


bool carattereVocale(char a){

        if (a =='A' || a == 'E' || a== 'I'|| a == 'O' || a=='U'||
	    a == 'a' || a=='e'|| a=='i' || a =='o' || a == 'u'){
 
               return TRUE;
        }

        else{
                return FALSE;
        }
}


AnalisiStringa AnalizzaStringa(Stringa stringa){

AnalisiStringa analisiStringa;

int len =0, numeroVocali=0, sommaASCII = 0;

	len = strlen(stringa);

	/*
	while(stringa[len]!='\0'){
		len++;	
	}	
	*/
	for(int i =0;i<len;i++){
		
		sommaASCII += stringa[i];

		if((stringa[i]>='a' && stringa[i]<='z') ||
		    (stringa[i]>='A' && stringa[i]<='Z')) {
		
		 	if (carattereVocale(stringa[i])){
				numeroVocali ++;
        		}

		}
	}
	analisiStringa.lunghezza = len;
	analisiStringa.numeroVocali = numeroVocali;
	analisiStringa.sommaAscii = sommaASCII;

	return analisiStringa;
}


