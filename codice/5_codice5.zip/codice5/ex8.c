
#include<stdio.h>
#define DIM 100




void ordina(int a[], int d);
void StampaMediana();

int main(){
	StampaMediana();
}


/* ordina un array dal minore al maggiore */

void ordina(int a[], int d){

	int i,j,t;
	
	for(i=0; i<d; i++){
		for(j=i+1;j<d;j++){
			if(a[i]>a[j]){
				t=a[j];
				a[j]=a[i];
				a[i] = t;
			}	
		}
	}

}


void StampaMediana(){
	
	int n=1,i=0,d;
	int a[DIM];
	float t1,t2,med;	
	
	while(n!=0 && i!=(DIM-1)){
		printf("Inserisci un numero:\n");
		scanf("%d",&n);
	
		if((n!=0) && (n%3)==0 ){
			a[d++]=n;	
		}
		
	}
	

	ordina(a,d);		

	t1 = a[(d/2)-1];
	t2 = a[d/2];

	if (d%2 == 0){
		med = (t1 +t2)/2;	
	}
	else{
		med = t2;
	}	 

	printf("La mediana e'%f\n",med);
}



