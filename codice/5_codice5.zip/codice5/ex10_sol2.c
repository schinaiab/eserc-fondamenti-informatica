#include<stdio.h>
#include<string.h>

#define MAX_L 30 /* Lunghezza massima stringa */

typedef enum{FALSE,TRUE} bool;
typedef char Stringa[MAX_L];



void AnalizzaStringa(Stringa stringa, int * lunghezza, int * numeroVocali, int * sommaAscii);

bool carattereVocale(char a); /* restituisce TRUE se il carattere e' una vocale */

int main(){

	Stringa stringa;
	int lunghezza, numeroVocali, sommaAscii;

	printf("Inserisci una stringa (max %d caratteri):\n",MAX_L);
	scanf("%s",stringa);

	AnalizzaStringa(stringa,&lunghezza,&numeroVocali,&sommaAscii);


	printf("Lunghezza della stringa: %d \nNumero di vocali: %d\nSomma ASCII %d\n",
	lunghezza,numeroVocali,sommaAscii);
}


bool carattereVocale(char a){

        if (a =='A' || a == 'E' || a== 'I'|| a == 'O' || a=='U'||
	    a == 'a' || a=='e'|| a=='i' || a =='o' || a == 'u'){
 
               return TRUE;
        }

        else{
                return FALSE;
        }
}


void AnalizzaStringa(Stringa stringa, int * lunghezza, int * numeroVocali, int * sommaAscii){


	*lunghezza = strlen(stringa);

	/*
	while(stringa[*lunghezza]!='\0'){
		*lunghezza++;	
	}	
	*/
	
	for(int i =0;i<(*lunghezza);i++){
		
		*sommaAscii+= stringa[i];

		if((stringa[i]>='a' && stringa[i]<='z') ||
		    (stringa[i]>='A' && stringa[i]<='Z')) {
		
		 	if (carattereVocale(stringa[i])){
				(*numeroVocali)++;
        		}
		}
	}

}


