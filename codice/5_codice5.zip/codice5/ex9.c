
#include<stdio.h>
#define DIM 20 /* lunghezza campi testuali*/
#define MATR 6 /* lunghezza max matricola */
#define ESAMI 30 /* numero massimo esami */

/* definiamo il campo stringa */
typedef char Stringa[DIM];

/* definiamo il campo matricola */
typedef char Matricola[MATR];


typedef struct{
	int voto;
	int crediti;
}Esame;

/* struttura per uno studente */

typedef struct{

	Stringa nome;
	Stringa cognome;
	Matricola matricola;
	Esame voti[ESAMI];
	int esami;
	float media;
} Studente;

void inserisciEsame(Studente *s , Esame e);

int main(){

	Studente studente = {"Mario","Rossi","123456"};
	
	Esame esami[2] = { {25,5},
			    {30,10}
			 };

inserisciEsame(&studente,esami[0]);
inserisciEsame(&studente,esami[1]);

printf("La media esami di %s %s e' %f\n",studente.nome,studente.cognome,studente.media);
}

void inserisciEsame(Studente *s , Esame e){

	int i, c = 0;
	float v = 0.0;

	/* aggiornamento nuovo esame */
	(s->voti[s->esami]).voto = e.voto;
	(s->voti[s->esami]).crediti = e.crediti;
	(s->esami)++;

	/* aggiornamento media studente */

	for(i=0; i < s->esami;i++){
		v+=  ((s->voti)[i].voto * (s->voti)[i].crediti);
		c+= (s->voti)[i].crediti;
	}
	
	s->media = v/c;

}