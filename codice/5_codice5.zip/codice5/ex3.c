#include<stdio.h>

void scambiaInteri(int *p1, int *p2);

int main(){

	int n1, n2;

	/* Inserisco i due valori */
	scanf("%d",&n1);
	scanf("%d",&n2);

	/* e li stampo */
	printf("n1=%d n2=%d\n",n1,n2);

	/* chiamo la funzione scambiaInteri
	   e scambio i valori
	   N.B. i valori di n1 ed n2 sono
		passati per indirizzo
	*/
	scambiaInteri(&n1,&n2);

	/* stampo di nuovo i contenuti di n1 e n2 */
	printf("n1=%d n2=%d\n",n1,n2);

}
void scambiaInteri(int * p1, int * p2){

	int tmp; /* variabile temporanea*/
	tmp = *p1;
	*p1=*p2;
	*p2=tmp;
}
