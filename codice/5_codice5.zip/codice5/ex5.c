#include<stdio.h>
#define MAX 5

float calcolaMedia(int *sequenza,int n);

int main(){

int a[MAX];
printf("\nInserisci 5 numeri interi e premi invio: \n");
scanf("%d %d %d %d %d",&a[0],&a[1],&a[2],&a[3],&a[4]);

float media = calcolaMedia(a,MAX);
printf("\nmedia = %f\n",media);
}

float calcolaMedia(int *sequenza,int n){

/* gli array sono sempre copiati per riferimento, 
   devo quindi passare anche il numero di elementi
   della sequenza */

	float media = 0;
	for (int i=0;i<n;i++){
		media += sequenza[i];
	}
	media = media/n;
	return media;
}