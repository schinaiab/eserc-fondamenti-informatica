#include<stdio.h>
#include<stdlib.h>
#define NUM_LEN 10

void dividi(FILE *file, int n){

	int i;
	/* Legge tutti i numeri 
	   contenuti nel file
	*/
	while(fread(&i,sizeof(int),1,file)!=0){
		i/=n; /* Divide il numero letto*/
		/*
		Ritorna indietro nel file
		*/
		fseek(file,-sizeof(int),SEEK_CUR);
		/* 
		E sovrascrive il numero letto
		*/
		fwrite(&i,sizeof(int),1,file);
		
	}
}

int main(){

	FILE *file;
		
		/* 
		Generiamo un file binario contenente
		gli interi da 1 a 10
		*/

		int numbers[NUM_LEN] ={1,2,3,4,5,6,7,8,9,10};

	
		if((file = fopen("dividi","wb+"))==NULL){
			puts("Errore lettura file");
			exit(1);
		}
		fwrite(numbers,sizeof(int),NUM_LEN,file);

		/* Stampiamo il contenuto del file */	
		rewind(file);
		int a[NUM_LEN];
		fread(a,sizeof(int),NUM_LEN,file);
		for(int i=0;i<NUM_LEN;i++){
			printf(" %d ",a[i]);
		}
		fclose(file);
		


		/* apriamo il file appena generato*/
		if((file = fopen("dividi","rb+"))==NULL){
        	        puts("Errore lettura file");
                	exit(1);
        	}
	
	/* 
	eseguiamo la funzione dividi sul file
	e stampiamo il risultato
	*/
		
	dividi(file,3);
	rewind(file);	
	  int i;
	  printf("\n");
	  while(fread(&i,sizeof(int),1,file)!=0){
		printf(" %d ",i);	
	 }
	
	fclose(file);
	printf("\n");
}