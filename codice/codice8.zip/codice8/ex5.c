#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*Funzione che recupera una parola dal file (alternativa alla fscanf di una stringa)
void sottostringa(FILE *file, char *parola) {
  int indice = 0;
  char c;
  do {
    c = fgetc(file);
    if(c == ' ' || c == EOF)
      parola[indice] = '\0';
    else
      parola[indice] = c;
    indice ++;
  } while(c != ' ' && c != EOF);
}
*/

int ricerca(char * parola,FILE*file){
	char s[100];
	int n=0;

	rewind(file);
	do{
		 /*sottostringa(file,s);*/
		fscanf(file,"%s",s);
	
		/* 
		Confronto la parola da cercare
		e quella letta
		*/
		if(strcmp(s,parola)==0){
			n++;
		}
		printf("%d %s\n",strcmp(s,parola),s);
	}while(!feof(file));
	
	return n;
}

int main(){

	FILE * file;
	
	if((file = fopen("ricerca.txt","r"))==NULL){
		puts("Errore apertura file");
		exit(1);
	}
	printf("Numero occorrenze: %d\n",ricerca("asso",file));

	fclose(file);
}