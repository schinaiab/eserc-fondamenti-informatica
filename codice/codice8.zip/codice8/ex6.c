#include<stdio.h>
#include<stdlib.h>

/* Funzione ricorsiva ausiliaria */
void numPari_ricorsiva(FILE *input, FILE *output){
	int i;
	/* Legge un 'intero*/
	if(fread(&i,sizeof(int),1,input)!=0){
		/* Richiama se stessa in modo ricorsivo (stampa quindi prima il prossimo intero)*/
		numPari_ricorsiva(input,output);
		if(i%2==0){
		/* Stampa l'intero pari letto dopo aver terminato la chiamata ricorsiva */
		fwrite(&i,sizeof(int),1,output);
		}
	}
}

/* Funzione principale che crea il file di output e richiama la funzione ricorsiva */
FILE *numPari(FILE *input){
	FILE *output;

	if((output = fopen("numeriPari","rb+")) == NULL){
		return NULL;
	}
	rewind(input);
	numPari_ricorsiva(input,output);
	return output;

}



int main(){

	FILE *input, *output;
	int n;

		/* Generiamo un file binario contenente gli interi
		   da 1 a 100
		*/
		if((output=fopen("numeri_contrario","wb"))==NULL){
                        puts("Errore lettura file");
                        exit(1);
                }       
                int i;
                for(i=1;i<=100;i++){
                        fwrite(&i,sizeof(int),1,output);
                }       
                fclose(output);


		/* 
		  Stampiamo a stdin il file appena generato
		*/		
		
		
		if((input=fopen("numeri_contrario","rb"))==NULL){
			puts("Errrore lettura file");
			exit(1);
		}

		/* Stampiamo il file di input */
		printf("INPUT\n");
		while(fread(&n,sizeof(int),1,input)!=0){
                                printf(" %d ",n);
                        }	
	
		output = numPari(input);
		fclose(input);		
	
		
		/* stampiamo il file generato */			
		if(output!=NULL){
			printf("\n OUTPUT \n");
			rewind(output);
			fread(&n,sizeof(int),1,output);
			while
			(fread(&n,sizeof(int),1,output)!=0){
				printf(" %d ",n);
			}
			printf("\n");
			fclose(output);
		}
						
}





