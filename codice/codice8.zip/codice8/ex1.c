#include<stdio.h>
#include<stdlib.h>
#define MAX_READ 120


/* funzione ricorsiva */


void contrario(FILE * file){

	if(!feof(file)){ /* feof(FILE * stream) testa il flag end-of-file 
			    per lo stream stream.
			  */
	char stringa[MAX_READ];
	fgets(stringa,MAX_READ,file); 

	/* 
	char *fgets(char *s, int size, FILE *stream); 
        	legge una linea dallo stream immagazzinandola 
		nel buffer puntato da s.
	
	Sono letti al piu' (size - 1) caratteri, 
	oppure fino al raggiungimento del carattere 
	di new-line '\n' o di EOF
	*/
	
	/* Chiamata ricorsiva
	   N.B. ogni volta che effettuiamo la 
		lettura il puntatore a file 
		viene spostato avanti di MAX_READ caratteri
		nel nostro caso leggiamo una riga per volta
		dato che non abbiamo righe con piu' di 120
		caratteri
	*/
	contrario(file);
	
	/* al termine della chiamata ricorsiva stampiamo la
	   riga letta
	   N.B. siccome la printf e' dopo la chiamata ricorsiva
	   inizieremo a stampare dalla fine del file
	*/
	printf("%s",stringa);
		
	}

}




int main(){
	FILE *file;

	if( (file = fopen("ex2.c","r")) == NULL){
		puts("Non e' possibile aprire il file");
		exit(1);
	}
	rewind(file); /* ci riposizioniamo
			 all'inizio del
			 file per 
			 sicurezza
		      */
	contrario(file);
	fclose(file);
}
