#include<stdio.h>
#include<string.h>
#include<stdlib.h>

#define MAX_NOME 30
#define MAX_TEL 11
#define MAX_CONTATTI 100

typedef struct{

	char nome[MAX_NOME];
	char telefono[MAX_TEL];
} Contatto;

typedef struct{

	Contatto contatti[MAX_CONTATTI];
	int numero_contatti;

} Rubrica;

/* Salva l'array di contatti su un file binario*/

void salva(FILE *file, Rubrica rubrica){

	fwrite(rubrica.contatti, sizeof(Contatto),rubrica.numero_contatti,file);
	
}

/* Leggere l'array di contatti da un file binario */
void ripristina(FILE*file, Rubrica * rubrica){

	/* Recupero il numero di contatti in base alla
	   dimensione del file 
	*/
	fseek(file,0,SEEK_END);
	
		
	rubrica->numero_contatti = ftell(file)/sizeof(Contatto);	

	
	/* 
	Ricomincio la lettura dall'inizio del file
	*/
	rewind(file);
	
	/* Leggo i contatti */
	fread(rubrica->contatti,sizeof(Contatto),rubrica->numero_contatti,file);
}

int main(){

	Rubrica rubrica1 = {
			   {{"Mario", "000000"},
       			   {"Filippo", "000001"},
       			   {"Giulia", "000002"}},
      			   3
    			   };
	FILE *file;
	if((file=fopen("rubrica.bin","wb"))==NULL){
		puts("Non e' possibile aprire il file in scrittura");
		exit(1);
	}
	salva(file,rubrica1);
	fclose(file);
	
	/* Dichiaro un'altra struttura rubrica */
	Rubrica rubrica2;
	int i;
	FILE * file2;
	if((file2=fopen("rubrica.bin","rb"))==NULL){
                puts("Non e' possibile aprire il file in lettura");
                exit(1);
        }
	ripristina(file2,&rubrica2);
	fclose(file2);
	for(i=0;i<rubrica2.numero_contatti;i++){
		printf("%s - %s\n",rubrica2.contatti[i].nome,rubrica2.contatti[i].telefono);
	}	
}
