#include<stdio.h>
#include<stdlib.h>



void media(FILE *file){

	int numero_interi, indice,n;
	double media = 0;

	rewind(file);

	/*
	Leggo il numero n di interi contenuti
	*/
	fscanf(file,"%d",&numero_interi);
	
	/*
	Leggo iterativamente n interi 
	*/
	for(indice=0;indice<numero_interi;indice++){
		fscanf(file,"%d",&n);
		media+=n;
	}
	media /=numero_interi;
	/*
	Stampo la media in un formato appropriato
	*/
	fprintf(file," %.2f",media);
}


int main(){

	FILE *f;
	if ((f=fopen("media.txt","r+"))==NULL){
		puts("Errore apertura file");
		exit(1);
	/* r+ apre un file e abilita update
	   w+ apre file e cancella i contenuti
	      se non esiste lo crea
	*/
	}
	media(f);
	fclose(f);
}