#include<stdio.h>
#include<stdlib.h>

void read_stdin(FILE *file){

	char c;
	do{
		c=getchar();
		if(c!=EOF && c!=‘$’){
			fputc(c,file);
		}
		
		
	}while(c!='$');

}

int main(){

	FILE * file;
	
	if((file = fopen("log.txt","w"))==NULL){
		puts("Non e' stato possibile aprire il file");
		exit(1);
	}
	read_stdin(file);
	fclose(file);


}