#include<stdio.h>
int main(){
    // non mi serve veramente un array se devo solo calcolare 
    // la differenza tra massimo e minimo
    int valore; // intero letto
    int i = 0; // contatore valori letti
    
    int massimo, minimo;
    int differenza;     	   
    
    scanf("%d",&valore);
    // inizializzo il valore massimo e minimo al primo valore letto
    massimo = minimo = valore;
    // continuo a leggere fino a che il valore 0 non viene letto
    while(valore!=0){
        if(valore > massimo){
            massimo = valore;
        }    
        if(valore< minimo){
        minimo = valore;
        }
        //leggi il prossimo valore
    scanf("%d",&valore);
    }
    differenza = massimo - minimo;
    printf("Differenza tra max %d e min %d: %d\n",massimo,minimo,differenza);
    
}
