#include<stdio.h>
int main(){
    int A;
    int B;

    // Richiediamo di inserire due numeri
    // continuamente finche' entrambi non
    // sono >0	
    do{
    printf("Inserisci due numeri A>0 e B>0:\n");
    scanf("%d%d",&A,&B);
    }while(A<=0 || B<=0);	
        
    // devo identificare il valore maggiore e minore
    int minore = 0;
    int maggiore = 0;
    
    if(B<A){
        minore = B;
        maggiore = A;
    }
    else{
        minore = A;
        maggiore = B;
    }
    
    // partendo dal maggiore, controllo se e' divisibile per il minore 
    // e lo decremento di uno ad ogni ciclo
    while(maggiore >= minore){
        if(maggiore % minore == 0){
        printf("%d\n",maggiore);
        }
        maggiore = maggiore -1;
    }
    printf("\n");
}
