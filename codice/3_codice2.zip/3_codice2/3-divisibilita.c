#include<stdio.h>

#define MAX 100 // Dimensione massima di n

int main(){

	// Dichiarazione delle variabili
	int n;
	int matrice[MAX][MAX];
	int i,j;

	// Lettura del numero n
	do{
	printf("Inserisci un numero n>0\n");
	scanf("%d",&n);
	}while(n<=0); // accetto solo un n positivo

	// calcolo dei valori della matrice
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			matrice[i][j] = (i+1)*(j+1);
		
		}
	}
	
	// stampa i valori della matrice

	// prima stampa l'intestazione
	printf("  ");
	for(i=0;i<n;i++){
		printf("%d ",i);
	}
	printf("\n");
	// stampa delle righe della matrice
	for(i=0;i<n;i++){
		printf("%d ",i); // intestazione di riga
		for(j=0;j<n;j++){
		printf("%d ",matrice[i][j]);
		}	
	printf("\n");	
	}		
}
