#include<stdio.h>

#define STRLEN 30
#define NLIBRI 100


typedef struct{
	char nome[STRLEN];
	double costo;
	int giacenza;
}Libro;

typedef struct {
	Libro libri[NLIBRI];
	int numero_libri;

}Libreria;


void stampa_libri(Libreria libreria){

	if(libreria.numero_libri>0){

	Libro libro = libreria.libri[libreria.numero_libri-1];
	
	if(libro.giacenza>0){
		printf("%s %d\n",libro.nome, libro.giacenza);
		libreria.numero_libri--;
		stampa_libri(libreria);
	}

	}
}



int main(){

	Libreria libreria = {{
		{"Informatica",10.0,3},
		{"Matematica",20.0,5},
		{"Statistica",5.0,2}
		},3};
		
	stampa_libri(libreria);	
}
