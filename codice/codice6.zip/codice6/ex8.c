#include<stdio.h>

void f(int a){

	if(a>0){
		f(a/2);
		printf("%d",(a%2));
	}

}


void g(int a){

        if(a>0){
                printf("%d",(a%2));
		g(a/2);
        }

}



int main(){

	int a;
	scanf("%d",&a);
	f(a);
	printf("\n");
	g(a);
	printf("\n");

}

