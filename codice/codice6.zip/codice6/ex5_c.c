#include<stdio.h>

int converti(int * array, int n){

	static int potenza = 1;

	if(n==0){
		potenza = 1;
                return 0;
	}

	else{

		int p = array[n-1] *potenza;
		potenza *=2;
		return p + converti(array, n-1);
	}
}





int main(){

        int array[] = {1,0,1};
        printf("Risultato %d\n",converti(array,3));
}
