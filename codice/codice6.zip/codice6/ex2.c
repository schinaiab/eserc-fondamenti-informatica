
#include<stdio.h>

int lunghezza(char * frase){

	/* caso base: l'array e' vuoto: */
	if(*frase == '\0'){
		return 0;
	}

	else{
		return lunghezza(frase +1) +1;
	}

}




int main(){
	char frase[] = "Questa e' una frase\0";
	printf("Lunghezza frase: %d\n",lunghezza(frase));
}


