#include<stdio.h>
#define MAX 30


typedef struct{
	char nome[MAX];
	char cognome[MAX];
}Persona;


void stampa_persona(Persona * persona){

	printf("%s %s\n", persona->nome,persona->cognome);
}

void stampa_persone(Persona * persone, int n){

	if(n>0){
	//	stampa_persona(persone);
		stampa_persone(persone+1,n-1);
		stampa_persona(persone);
	}
}




int main(){

Persona persone[] = { {"Mario", "Rossi"},
		      {"Filippo", "Bianchi"},
		      {"Giulia", "Verdi"}
			};

	
stampa_persone(persone,3);
}
