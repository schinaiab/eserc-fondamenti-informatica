#include<stdio.h>



int potenza(int base, int esponente){

	if(esponente ==0){
		return 1;
	}
	else{
		return base * potenza(base,esponente-1);
	}
	
}


int converti(int * array, int n){

	if(n==0){
		return 0;
	}

	else{
		return array[0]*potenza(2,n-1) + converti(array+1,n-1);
	}	

}



int main(){

        int array[] = {1,0,1};
        printf("Risultato %d\n",converti(array,3));

}
