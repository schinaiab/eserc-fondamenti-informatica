#include<stdio.h>


int massimo(int * array, int n){

	if(n==0){
		return 0;
	}

	else if(n==1){
		return * array;
	}

	
	else{
		int max = massimo(array +1, n-1);
	
		if(array[0]> max){
			return array[0];
		}


		else{
			return max;
		}

	}

}



int main(){

	int array[] = {1,5,2,7,3,8,5};

	printf("Il numero massimo dell'array e' %d\n",massimo(array,7));
}
