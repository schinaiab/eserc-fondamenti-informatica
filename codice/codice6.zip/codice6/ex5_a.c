#include<stdio.h>


int converti(int * array, int n, int potenza){

	if(n==0){
		return 0;
	}

	else{
		return array[n-1] * potenza + converti(array,n-1,potenza*2);
	}

}





int main(){

	int array[] = {1,0,1};
	printf("Risultato %d\n",converti(array,3,1));

}
