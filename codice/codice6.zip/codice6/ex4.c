#include<stdio.h>

int f(int *array, int n){

	if(n<=0){
		return 0;
	}
	else if (n==1){
		return array[0]*array[0];
	}
        else{
		return array[0] * array[n-1] + f(array +1, n-2);
	}
}


int main(){

	int array[] = {1,2,3,4,5};
	printf("Il risultato e' %d\n",f(array,5));

}


