#include<stdio.h>
#define MAX 100

void maiuscolo(char *frase){

	if(*frase!='\0'){
		
		/* se il carattere e' una lettera minuscola */
		if(*frase>='a' && *frase <='z'){
		
			*frase -= 'a' - 'A';
		}
		
		maiuscolo(frase +1);
	
	}

}



int main(){

	char frase[MAX] = "Questa e' una frase\0";
	printf("La frase \n%s \n e' trasformata in: \n",frase);
	maiuscolo(frase);
	printf("%s\n",frase);
	
}
