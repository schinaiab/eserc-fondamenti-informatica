#include <stdio.h>
#define MAX 10
//
int main(int argc, const char * argv[]) {
int A[MAX] = {3,4,66,77,88,9,33,11, 66,100};
int B[MAX/2] = {77,88,9,343,11};
// per semplicita mettiamo il calcolo vero e proprio senza lettura / scanf...
int i, j=0;

// lettura


for (i=0; i<MAX ; i++) {
  scanf("%d",&A[i]);
}
for (i=0; i<MAX/2 ; i++) {
  scanf("%d",&B[i]);
}

for (i=0; i<MAX && j<MAX/2; i++) {
if (A[i] == B[j]){
j++;
}else{
j=0;
}
}
if (j == MAX/2)
printf("CONTIENE\n");
else
printf("non CONTIENE\n");
return 0;
}
