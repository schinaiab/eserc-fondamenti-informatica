#include<stdio.h>

int main(){

	/*modi alternativi per definire una struct*/


	/*A definire una struttura senza definire un nuovo tipo*/
	struct A{
	
	int intero;
	char carattere;
	float reale;
	};
	
	/* se voglio dichiarare una variabile di tipo prova devo usare
	   una struct prova*/ 
	
	struct A prova;
	prova.intero = 1;
	prova.carattere='P';
	prova.reale = 0.24;

	/* stampiamo il contenuto di prova:*/
	printf("\nA) definire una struttura senza definire un nuovo tipo.\n");
	printf("\nintero: %d\n",prova.intero);
	printf("carattere: %c\n",prova.carattere);
	printf("reale: %f\n",prova.reale);


	/* B definire una struttura senza definire un nuovo tipo e con una nuova variabile
	
	   N.B. subito dopo la definizione della struct posso definire una serie di
	   variabili della struttura*/
	
	struct B{
		int intero;
		char carattere;
		float reale;
		} prova2;

	prova2.intero = 1;
	prova2.carattere = 'P';
	prova2.reale = 0.24;	
	
	printf("\nB) definire una struttura senza definire un nuovo tipo e con una nuova variabile.\n");
        printf("\nintero: %d\n",prova2.intero);
        printf("carattere: %c\n",prova2.carattere);
        printf("reale: %f\n",prova2.reale);


	/*C definire una struttura definendo un nuovo tipo
	  Provare a copiare una variabile struttura in un altra e stampare il risultato.*/
	
	typedef struct{
		int intero;
		char carattere;
		float reale;
	} C;

	C prova3;
	
	prova3.intero = 1;
        prova3.carattere = 'P';
        prova3.reale = 0.24;	
	
	printf("\nC) definire una struttura definendo un nuovo tipo\n");
        printf("\nintero: %d\n",prova3.intero);
        printf("carattere: %c\n",prova3.carattere);
        printf("reale: %f\n",prova3.reale);		

	/*Provare a copiare una variabile struttura in un altra, modificarla e stampare il risultato.*/
	C prova4;
	
	prova4=prova3;
	prova4.intero=4356;

	printf("\nC) struttura copiata e modificata\n");
        printf("\nintero: %d\n",prova4.intero);
        printf("carattere: %c\n",prova4.carattere);
        printf("reale: %f\n",prova4.reale);	

}
