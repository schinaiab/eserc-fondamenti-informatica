#include<stdio.h>
#define MAXS 20   /* Lunghezza massima dei nomi delle squadre */
#define MAXA 6   /*  Massimo numero di squadre memorizzabili  */


/* Definisco un tipo per i campi testuali
   N.B. C non ha un tipo stringa!!! */
typedef char String [MAXS]; // qui salveremo i nomi delle squadre

/* Definisco una struttura per memorizzare una squadra */

typedef struct {
	String nome;
	int ID;
	int goal_fatti;
	int goal_subiti;
	} Squadra;

/* Dichiarazione della sequenza di squadre come array di strutture */

typedef Squadra Campionato[MAXA];

int main(){

	Campionato campionato = {
		{"Juventus",1,10,12},
		{"Milan",8,7,6},
		{"Inter",10,13,11},
		{"SPAL",2,9,10},
		{"Pizzighettone",5,8,4},
		{"Udinese",14,5,7}
	};
	for (int i=0; i<MAXA; i++){
		if(campionato[i].goal_fatti > campionato[i].goal_subiti){
			printf("%s differenza goal: %d \n", 
			campionato[i].nome,
			campionato[i].goal_fatti-campionato[i].goal_subiti);
		}
     }
}
