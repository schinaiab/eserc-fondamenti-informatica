#include<stdio.h>
#define MAXS 30 /* lunghezza massima campi testuali */
#define MAXP 3  /* numero massimo persone in anagrafica */

/*  Enumero tutti i mesi */ 
typedef enum{GEN=1, FEB, MAR, APR, MAG, GIU,
	     LUG, AGO, SET, OTT, NOV, DIC} Mese;

/*  Definisco un tipo per i campi testuali */
typedef char String [MAXS];

/*  Struttura per memorizzare una data_nascita */
typedef struct{
int giorno;
Mese mese;
int anno;
} Data;

/*  Struttura con i dati di una persone */
typedef struct{
String nome;
String cognome;
Data data_nascita;
} Persona;

/*  Dichiarazione dell'anagrafica come collezione di strutture persona */
typedef Persona Anagrafica[MAXP];

int main(){
	Anagrafica anagrafica = {
		{"Mario","Rossi",{10,APR,1980}},
		{"Filippo","Bianchi",{10, APR,1970}},
		{"Maria","Verdi",{5,APR,1990}}
	};

	int i;

	/*  Calcolo della persona più giovane */

	/*  Inizializzo il risultato con la */
	/*  prima persona di anagrafica */
	Persona piu_giovane = anagrafica[0];
	
	/*  Cicliamo attraverso tutte le persone */
	/*  contenute in anagrafica */
	for(i=0;i<MAXP;i++){	
		/*  confronto sull'anno */
		if(piu_giovane.data_nascita.anno != anagrafica[i].data_nascita.anno){
			if(anagrafica[i].data_nascita.anno>piu_giovane.data_nascita.anno){
				piu_giovane = anagrafica[i];
			}
		}
		/*  confronto sul mese */
		else{
			if(piu_giovane.data_nascita.mese != anagrafica[i].data_nascita.mese){
                	if(anagrafica[i].data_nascita.mese>piu_giovane.data_nascita.mese){
                        	piu_giovane = anagrafica[i];
                	}
        	}
		/*  confronto sul giorno */	
		
			else{
                if(piu_giovane.data_nascita.giorno != anagrafica[i].data_nascita.giorno){
                    if(anagrafica[i].data_nascita.giorno>piu_giovane.data_nascita.giorno){
                            piu_giovane = anagrafica[i];
                    }
                }
            }
        }
	}/*  fine ciclo for */
	
	printf("La persona piu' giovane e' %s %s\n",piu_giovane.nome,piu_giovane.cognome);
}
