 #include <stdio.h>
 int main() {
   int n, i, j;
   i = 0, j = 0;

   printf("Inserire la lunghezza del lato: ");
   scanf("%d", &n);

   while (i < n) {
    while (j <= i) {
       printf("*");
       j++;
		}
     printf("\n");
     j = 0;
	}
  i++;
 return 0;
}