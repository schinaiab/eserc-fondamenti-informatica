#include<stdio.h>
#include<string.h> /* contiene funzioni specifiche per
 le stringhe */
int main(){

	char s[30];
	char temp; /* variabile temporanea */
	int i;
	int lunghezza;

	printf('Inserire una stringa: \n');
	scanf('%s',s);

	lunghezza = strlen(s);

	for (i=0; i<lunghezza/2; i++){
		temp = s[lunghezza - i - 1];
		s[lunghezza - i - 1] = s[i];
		s[i] = temp;
	}	

	printf("\n%s<------ parola invertita\n",s);


}