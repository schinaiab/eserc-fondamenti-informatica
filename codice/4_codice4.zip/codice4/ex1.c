#include<stdio.h>

int main(){
int i= 65;
int j = 'A';
int k="$";    //-->int k='$';

int u=i+k;

char v = 122;

printf("%d %d %d %d %c %d %c\n",i ,j ,k,u,u,v,v);
}
