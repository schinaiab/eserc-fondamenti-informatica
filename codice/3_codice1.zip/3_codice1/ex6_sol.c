#include<stdio.h>
// limits.h contiene le definizioni di INT_MIN e INT_MAX
// cioe' il numero intero minore e maggiore rappresentabile in C
#include<limits.h>
// N.B. definire MAX con un numero negativo causa un errore in compilazione // perche' viene usato per definire la lunghezza di un array
// e non si puo' definire un array con lunghezza negativa
#define MAX 5
    int main(){
    int a[MAX],i=0,massimo=INT_MIN;
    //N.B. la condizione non puo' essere i<=MAX, ma i < MAX
    // altrimenti si accederebbe ad a[MAX] che non e' definito
    while(i<MAX){
        scanf("%d",&a[i]);
        // manca un'istruzione per modificare il contatore
        // il ciclo continuerebbe all'infinito
        i= i + 1;
    // manca la parentesi di chiusura del ciclo
    }
    while(i>0){
        //  alla prima iterazione di questo ciclo, i == MAX
        // devo quindi decrementarlo di 1
        // prima di poter accedere all'array
        i = i - 1;
        // la condizione di controllo e' sbagliata
        // aggiorno il massimo se e' minore del valore di a controllato
    if(massimo< a[i])
        // devo aggiornare il massimo con il valore a[i]
        // non con l'indice
        massimo = a[i];
    }
    printf("Massimo-> %d\n",massimo);
    }

