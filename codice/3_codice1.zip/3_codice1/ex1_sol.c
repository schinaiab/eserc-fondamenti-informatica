#include <stdio.h> 
    int main(){
        int i; 
        int j;
        // il simbolo & e’ necessario per salvare il numero 
        // letto nelle variabili
        scanf("%d%d",&i,&j);
        
        // il ";" rendeva il costrutto "if" inutile 
        if(i<j){ 
            printf("Minore!");
        }
}
