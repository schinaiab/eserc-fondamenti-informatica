#include<stdio.h>
int main(){
    float a,b;
    float c;
    scanf("%f%f",&a,&b);
    c=a/b;
    printf("%f",c);
}
