#include <stdio.h> 
    int main(){
    int i,j=1;
    scanf("%d",&i);
    while(i>0){
        j=j*i;
        i=i-1;
    }
    printf("%d\n",j);
    }
