#include <stdio.h> 
    int  main(){
        int i; 
        int j;
        // l'operatore di indirizzo & e' necessario 
        // per salvare il numero letto nelle variabili
        scanf("%d%d",&i,&j);
        
        if(i==j){ // questa e'la giusta condizione di         
                //  uguaglianza
            printf("%d e %d sono uguali!",i,j);
        }
	else{
            printf("%d e %d sono diversi!",i,j);
        }
}
