#include<stdio.h>
#define MAX 10
int main(){
    char a[MAX] = {'c','i','a','o',' '};
    int i = 4;
    
    while(i<MAX){
    scanf("%c",&a[i]);
    i=i+1;
    }
    
    i=0;
    
    while(i<MAX){
    printf("%c",a[i]);
    i=i+1;
    }
	printf("\n");
}
