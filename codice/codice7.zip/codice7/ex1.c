// modificare il codice per ottenere una modifica_persona
// che rende permanenti le modifiche 

#include<stdio.h>

#define MAXLENGTH 30

typedef struct{

	char nome[MAXLENGTH];
	char cognome[MAXLENGTH];
} Persona;

void stampa_persona(Persona p){

	printf("%s %s\n",p.nome,p.cognome);
}

void modifica_persona(Persona p){

	p.nome[0] = '\0';
}


int main(){

	Persona p = {"Mario", "Rossi"};
	stampa_persona(p);
	modifica_persona(p);
	stampa_persona(p);
}
