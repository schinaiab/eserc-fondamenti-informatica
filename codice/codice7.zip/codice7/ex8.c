#include<stdio.h>
#include<stdlib.h>

#define MAX 5

int main(){

	int *m;	
	int i,j;

	/* Rappresento la matrice come un unico array dove le righe della matrice 
	   sono state concatenate una dopo l’altra 
	*/
	m = (int*) malloc(sizeof(int) * MAX * MAX);

	for(i=0;i<MAX;i++){
		for(j=0;j<MAX;j++){
		/* Per accedere ad un elemento dell’array e' necessario calcolare 
		   la giusta posizione: Es: la cella di riga 1, colonna 2 
		   nella matrice (m[1][2]) e' l'elemento di posizione (1 * MAX + 2) 
		   nell'array
		*/
			m[i * MAX + j] = (i+1) * (j+1);
		}
	}

	for(i=0;i<MAX;i++){
                for(j=0;j<MAX;j++){
                        printf("%d ",m[i * MAX + j]); 
                }
                printf("\n");
        }
	free(m);

}
