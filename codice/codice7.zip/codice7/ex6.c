#include<stdio.h>
#include<stdlib.>

#define MAX 5

int main(){

	int *m[MAX]; /* dichiaro un array di puntatori ad intero*/
	/* N.B. -> ogni cella dell'array e' un puntatore */
	
	int i,j;

	for(i=0;i<MAX;i++){
	
		m[i] = (int*) malloc(MAX*sizeof(int)); 
		/* Alloco un’area di memoria 
		con l’equivalente di un array di interi di dimensione MAX e
		restituisco il puntatore ad una cella dell'array m. */
	
	 /* alla fine del ciclo ottengo una matrice MAX x MAX*/
	
		for(j=0;j<MAX;j++){
			m[i][j] = (i+1) *(j+1);
		/* per ogni cella di indice(i,j)
		   della matrice, calcolo (i+1) * (j+1).
	           Costruisco in pratica una tavola pitagorica.
		*/
		}
	}

	for(i=0;i<MAX;i++){
		for(j=0;j<MAX;j++){
			printf("%d ",m[i][j]); /* stampo ogni cella della tavola*/
		}
		printf("\n");
		free(m[i]); /* devo deallocare ogni array creato dinamicamente*/
	}

}
