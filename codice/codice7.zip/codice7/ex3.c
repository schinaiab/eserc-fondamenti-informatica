#include<stdio.h>
#include<stdlib.h>


int main() {

	int* p;
	int* m;

	p = (int*)malloc(sizeof(int));  /* alloco lo spazio di un intero */
	*p = 10;
	m = p;
	*m = (*p)++;    
	/*
		int temp = *p; *p += 1;
		*m = temp;
	*/

	printf("%d\n", *m); /* stampa 10 */

	*m = ++(*p); 
	/*
	*p += 1;
	*m = *p;
	*/

	printf("%d\n", *m); /* stampa 11 */
//	free(m);
}