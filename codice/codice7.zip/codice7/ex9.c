#include<stdio.h>
#include<stdlib.h>


/* Dichiaro la struttura che rappresenta un elemento della lista */

typedef struct EL{
	int valore;
	struct EL * next;
} Elemento;


/* Il tipo Lista e' semplicemente un puntatore al primo elemento della lista */

typedef Elemento * Lista;

/* procedura crea_lista: assegna alla testa di una lista il valore NULL,
	per simboleggiare che la lista e' vuota*/

void crea_lista(Lista * lista){
	*lista = NULL;
}

/* La procedura stampa_lista stampa in modo ricorsivo tutti gli elementi
della lista, dal primo all’ultimo */

void stampa_lista(Lista lista){

	if(lista != NULL){
		printf("%d ",lista->valore); /* stampa il valore dell’elemento corrente */
		stampa_lista(lista->next); /*Passo ricorsivo su cio' che rimane */	
	}
	else{
		printf("\n");
	}

}



void inserisci(Lista *lista, int valore) {

/* Se la lista e' terminata o il valore corrente e' maggiore
del valore da inserire, allora e' il momento di creare il nuovo elemento */

	if(*lista == NULL || (*lista)->valore > valore){
	/* Alloca nuova area di memoria */
	Elemento * el = (Elemento*) malloc(sizeof(Elemento));
	el->valore = valore; /* Assegna il valore */
	el->next = *lista;   /* Il nuovo elemento punta all’elemento corrente */
	*lista = el;         /* L’elemento precedente punta al nuovo elemento */
	}
	else{
		/* Altrimenti procedi ricorsivamente sul resto della lista */
		inserisci(&((*lista)->next), valore);
	}
}

int main(){

	Lista lista;
	crea_lista(&lista);

	printf("Lista ");
	stampa_lista(lista);
	
	
	inserisci(&lista, 3);
	inserisci(&lista, 1);
        inserisci(&lista, 5);
        inserisci(&lista, 3);
        inserisci(&lista, 2);
	printf("Lista");
	stampa_lista(lista);
}
