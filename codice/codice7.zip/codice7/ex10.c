#include<stdio.h>
#include<stdlib.h>


typedef struct EL{
	int valore;
	struct EL *next; /* Puntatore all’elemento successivo in lista */
	struct EL *prev; /* Puntatore all’elemento precedente in lista */
} Elemento;


/* La testa della lista e’ un elemento in cui il puntatore next punta al primo elemento della lista, mentre il puntatore prev punta all’ultimo elemento della lista */

typedef Elemento Lista;

/* Procedura che inizializza la lista come lista vuota (entrambi i puntatori a NULL */

void crea_lista(Lista * lista){

	lista -> next = NULL;
	lista -> prev = NULL;
}


/* Procedura che stampa la lista dal primo elemento all'ultimo */

void stampa_lista_forward(Lista lista){

	if(lista.next!=NULL){
		/* Invertendo l'ordine di printf e chiamata ricorsiva, si 
		   ottiene una stampa dall'ultimo elemento al primo */
		printf("%d ",lista.next->valore);
		stampa_lista_forward(*(lista.next));
	}
}

/* Procedura che stampa la lista dall'ultimo elemento al primo */
void stampa_lista_backward(Lista lista){

	if(lista.prev!=NULL){
		printf("%d ",lista.prev->valore);
		stampa_lista_backward(*(lista.prev));
	}
}

/* Procedura per l’inserimento di un nuovo elemento al termine della lista */
void inserisci(Lista * lista, int valore){

/* Non c’e’ bisogno di iterare fino all’ultimo elemento perche’ il
suo puntatore e' disponibile nella testa della lista */

	Elemento *elemento = (Elemento*) malloc(sizeof(Elemento));
	elemento->valore = valore;
	elemento->next = NULL;
	elemento->prev = lista->prev;
	
	if(lista->prev !=NULL){
		/* aggiorno il puntatore di quello che era l'ultimo
		   elemento della lista 
		*/
		lista->prev->next=elemento;
	}
	else{
		/* Nel caso la lista sia vuota, il nuovo elemento diventa il primo 		      della lista */
		lista->next=elemento;
	}	
	/* l'elemento diventa l'ultimo elemento della lista*/		
	lista->prev=elemento;	
}

int main(){

	Lista lista;
	
	crea_lista(&lista);
	inserisci(&lista,1);
	inserisci(&lista,3);
	inserisci(&lista,2);
	
	stampa_lista_forward(lista);
	printf("\n"); 
	stampa_lista_backward(lista);
	printf("\n");
}



