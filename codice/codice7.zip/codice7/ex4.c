#include<stdio.h>
#include<stdlib.h>


int main(){

	int i = 10, j = 20;
	int *p;
	p = (int*) malloc(sizeof(int)); /* alloco lo spazio di un intero*/
	*p = i;
	for(;*p<j;(*p)++){
		printf("%d\n",i);
	}

	p = &i;

	for(;*p<j;(*p)++){
		printf("%d\n",i); /* stampo i numeri da 10 a 19 */
	}
	
	free(p);

	/*
	il programma termina con un errore perche' tenta di deallocare una zona 
	non allocata in modo dinamico. 
	Infatti in riga 16 viene assegnato a p l'indirizzo della variabile i. 
	La memoria non viene deallocata in modo corretto.
	*/

}
