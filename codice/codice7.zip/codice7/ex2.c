#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAXLENGTH 30


typedef struct{
	char * nome;	
	char * cognome;
} Persona;


void alloca_persona(Persona * p, char nome[], char cognome[]){

	/* alloco in modo dinamico gli array che contengono
	   nome e cognome */

	p->nome =(char *) malloc(MAXLENGTH * sizeof(char));
	p->cognome = (char *) malloc(MAXLENGTH * sizeof(char));
	strcpy(p->nome,nome);
	strcpy(p->cognome,cognome);
}


void stampa_persona(Persona p){

	printf("%s %s\n",p.nome,p.cognome);
}


void modifica_persona(Persona p){
	p.nome[0] = '\0';
	/* N.B. in questo caso la struttura contiene dei puntatori
	ad una zona di memoria dinamica. Quando la funzione
	viene richiamata si effettua una copia di ogni suo attributo, 
	quindi una copia dei puntatori, ma non dell’area di memoria 
	allocata dinamicamente a cui essi puntano
*/
}

int main(){

	Persona p;
	alloca_persona(&p,"Mario","Rossi");
	stampa_persona(p);
	modifica_persona(p);
	stampa_persona(p);
}

