#include<stdio.h>
#include<stdlib.h>

#define MAX 5


int main(){

	int **m; /* puntatore a puntatori */
	int i,j;

	/* N.B. A differenza dell’esercizio 6, la matrice e’ completamente dinamica, sia per il numero di 		righe che di colonne */

	m = (int**) malloc(sizeof(int*) * MAX);

	for(i=0; i<MAX;i++){

		m[i] = (int*) malloc(MAX * sizeof(int));
		for(j=0;j<MAX;j++){
			m[i][j] = (i+1) *(j+1);
		}
	}

	for(i=0;i<MAX;i++){
                for(j=0;j<MAX;j++){
                        printf("%d ",m[i][j]); /* stampo ogni cella della tavola*/
                }
                printf("\n");
                free(m[i]); /* devo deallocare ogni array creato dinamicamente*/
        }

	/* E’ necessario deallocare anche la memoria dell’array di array */
	free(m);

}
