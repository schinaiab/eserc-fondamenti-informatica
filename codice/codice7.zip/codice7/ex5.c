#include<stdio.h>
#include<stdlib.h>
#define MAX 30



int main(){

	char *p,*k;

	p=(char*) malloc(MAX*sizeof(char));
	/* alloco uno spazio di memoria grande 30 volte un char,
	in pratica un array di char contente 30 elementi
	char p[30]; 
	*/

	/* leggo una stringa di testo e la salvo nella zona di memoria puntata da p */
	scanf("%s",p);

	k=p;
	printf("%s\n", k);
	/* dato che k punta alla zona di memoria allocata
	dinamicamente, stampo la stringa letta in input */
	

	for(;*k!='\0';k++){  /* uso il puntatore q per iterare lungo l’array */
		printf("%c",*k);
		/* stampo uno alla volta tutti i caratteri della
		   stringa letta in input */
	}
	
	printf("\n");
	free(k);
	/* libero la memoria
	nota: se avessimo fatto free(k), avremmo ottenuto un errore
	*/

}



